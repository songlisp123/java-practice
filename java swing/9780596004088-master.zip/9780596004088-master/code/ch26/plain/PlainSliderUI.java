// PlainSliderUI.java
//
package plain;
import java.awt.*;
import javax.swing.*;
import javax.swing.plaf.*;
import javax.swing.plaf.basic.*;

public class PlainSliderUI extends BasicSliderUI {
  // ...
  public PlainSliderUI(JSlider slider) {
    super(slider); 
  }
  // ...
}
