//  JogShuttleUI.java
// Fill out the proper UIClassID information for our JogShuttle.
//
import java.awt.*;
import javax.swing.*;
import javax.swing.plaf.*;

public abstract class JogShuttleUI extends ComponentUI {
    public static final String UI_CLASS_ID = "JogShuttleUI";
}
